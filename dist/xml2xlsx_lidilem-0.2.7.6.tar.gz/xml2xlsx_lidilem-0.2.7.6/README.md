# Documentation — xml2xlsx v0.2.7

## Nouveautés

### 1️⃣ Schéma DTD pour plus de précision
Le script peut maintenant lire un fichier DTD (schéma XML) pour découvrir automatiquement:
- Les éléments et leur hiérarchie
- Les attributs déclarés pour chaque balise
- L'ordre correct des balises

**Utilisation:**
```
--dtd /chemin/vers/schema.dtd
```

Sans DTD, le script utilise un schéma préfixé (INTRODD, PPI, VDD...).

---

### 2️⃣ Extraction généraliste
Le script n'est plus limité aux balises INTRODD/PPI/VDD. Il fonctionne avec **n'importe quel XML** tant que le DTD ou le schéma préfixé est fourni.
Le script permet également d'extraire les commentaires et de les mettre dans leur propre colonne dans le fichier Excel.
**Exemple:** Extraire un document avec tags `<chapter>`, `<section>`, `<paragraph>`:
```
$ xml2xlsx input.xml output.xlsx --dtd book.dtd
```

---

### 3️⃣ Test de conformité (Integrity Check)
Après conversion, le script compare automatiquement:
- **Nombre de balises** en Excel vs XML
- **Nombre d'attributs** par balise
- **Intégrité du contenu** (texte supprimé, attributs modifiés)

**Détecte:**
- Cellules vides manquantes (`❌ Erreur: VDD_type: Excel=193, xml=195`)
- Tags malformés ou supprimés
- Désynchronisation Excel ↔ XML

> **Exemple:** Le test a détecté `❌ p: Excel=516, xml=517` — une balise `<p>` malformée à la ligne 3652 du fichier '4-cest-pas-croyable_04_06_26.xml': '<p>"«</p> 

N.B: le test d'intégrité est conçu spécifiquement pour les balises INTRODD, VDD, etc., il ne supporte pas pour le moment d'autres types de corpus avec des balises différentes.
---

### 4️⃣ Mode Reverse: Injecter l'Excel vers XML

Modifiez le fichier Excel, puis réinjectez les changements dans l'XML original.

#### Comment utiliser le mode reverse?

**Étape 1: Sélectionner le mode**
```
Radio: "Réécrire XML depuis Excel"
```

**Étape 2: Sélectionner le fichier Excel modifié**
```
Chemin: /chemin/vers/document_modifié.xlsx
```

**Étape 3: Sélectionner le XML original**
```
XML original: /chemin/vers/document_original.xml
```

**Étape 4: Lancer**
```
Cliquer "▶ Lancer"
```

Résultat: `document_original_updated.xml`

---

#### Exemple: Ajouter une nouvelle balise

**Colonne Excel:**
```
INTRODD_2_zebbi_text
```

**Résultat XML:**
```xml
<INTRODD position="ante">
  <VDD type="parole">dit-il</VDD>
  <zebbi>nouveau contenu</zebbi>    ← CRÉÉ automatiquement
</INTRODD>
```

---

#### Exemple: Modifier un attribut

**Colonne Excel:**
```
VDD_type     →  "cognition"
```

**Résultat XML:**
```xml
<VDD type="cognition">dit</VDD>    ← Attribut modifié
```

---

#### Nommage des colonnes et ordre

**Syntaxe:**
```
[TAG]_[INDEX]_[TAG]_[ATTRIBUTE|_text]
```

| Colonne | Signification |
|---------|---------------|
| `INTRODD_text` | 1ère INTRODD, texte |
| `INTRODD_2_text` | 2ème INTRODD, texte |
| `INTRODD_position` | 1ère INTRODD, attribut "position" |
| `INTRODD_VDD_type` | VDD imbriquée dans INTRODD, attribut "type" |
| `INTRODD_2_VDD_3_text` | 3ème VDD dans 2ème INTRODD, texte |

**Important:** L'ordre des colonnes dans l'Excel ne change rien. L'ordre final suit le **schéma DTD** (ou préfixé).

---

#### Vérification après reverse

Le script exécute automatiquement un **test d'intégrité reverse** qui vérifie:
- ✓ Les balises existantes sont préservées
- ✓ Aucune perte de contenu
- ✓ Les nouvelles balises sont créées correctement
- ⚠️ Alertes si des données manquent

```
▶ Vérification de l'intégrité…
  ✓ Tag 'p': 516 (inchangé)
  ✓ Tag 'INTRODD' augmenté (125 → 126)
  ✓ Tag 'VDD': 498 (inchangé)
  ➕ Nouveau tag 'zebbi' (1 instance(s))
  ✅ OK: 1 nouveau(x) tag(s) ajouté(s), aucune perte
```

---

## Résumé

| Fonctionnalité | Avant | Maintenant |
|---|---|---|
| Schéma | Préfixé fixe | Lisible depuis DTD ou préfixé |
| Tags supportés | INTRODD, PPI, VDD... | N'importe quel XML |
| Validation | Manuelle | Automatique (nombre, contenu) |
| Modification | Non | Oui (mode reverse) |
| Intégrité | - | Test avant/après reverse |
